# BG Voice Logger v0.8.0 — обновяване на съществуващата инсталация

Източник: https://github.com/issaev/bg-voice-logger/commit/8a88b49b72057eb84b2594ea8c9c9a7ceaf83c66
WordPress: 0.8.0; очакван JS build: 0.8.0-5e642967a700.
Това е release candidate за приемателни тестове, НЕ потвърдена production версия. Пълният интегриран Node/PHP suite и реалните Android/iPhone/Sheets тестове още не са изпълнени. Не е правен deployment от ChatGPT.

## 1. Преди обновяването
- Запази копие на текущия WordPress плъгин v0.7.2.1, текущото Code.gs и Cloudflare Worker version.
- Използвай съществуващите deployment, WordPress опции и Cloudflare bindings/secrets. Не създавай нови ресурси и не променяй техните адреси.
- Не деинсталирай стария плъгин и не изтривай IndexedDB/локалната опашка/снимките/аудиото. По възможност изчакай активните акции и локалните записи да приключат.

## 2. Google Apps Script
1. Отвори СЪЩИЯ Apps Script проект, който обслужва сайта.
2. Замени съдържанието на Code.gs с apps-script/Code.gs от архива. Save.
3. Запази съществуващите Script Properties, включително BVLOG_SHARED_SECRET. Не сменяй shared secret, Google Drive папката или шаблона.
4. Deploy > Manage deployments > редактирай СЪЩИЯ Web App deployment > New version > Deploy. Запази съществуващия /exec URL и настройките Execute as Me / Access Anyone (проверява се съществуващият споделен ключ от WordPress).
5. При поискване одобри новите Google permissions. Новият range read използва UrlFetchApp и ScriptApp.getOAuthToken() за Google Drive API. Ако проектът има изрично описани oauthScopes, добави https://www.googleapis.com/auth/script.external_request към съществуващите scopes, без да ги премахваш. За частично четене на Drive може да е необходимо да активираш Google Drive API в свързания Google Cloud проект. При недостъпност на API кодът използва стария full-blob fallback; не предоставя публични Drive линкове.
6. WordPress Settings > BG Voice Logger > Test connection трябва да върне GAS version 0.8.0. Не редактирай конфигурираните URL и IDs.

## 3. Cloudflare Worker
1. Workers & Pages > отвори СЪЩИЯ STT Worker > Edit code.
2. Замени целия съществуващ код с workers/stt-worker.mjs. Това е ES module, не Service Worker classic script.
3. Запази съществуващите Variables and Secrets, bindings, domains и routes:
   - ALLOWED_ORIGIN = https://spasitelenclub.com
   - EXPECTED_ISSUER = https://spasitelenclub.com
   - AI (Workers AI binding)
   - STT_NONCES (съществуващ KV namespace)
   - STT_RATE_LIMIT (съществуващ rate limiting binding)
   - GROQ_API_KEY (Secret)
   - STT_HMAC_SECRET (Secret, идентичен на конфигурирания в WordPress)
4. Deploy на същия Worker. Отвори неговия /health: очаква се ok:true и prompt_profile:"sar-bg-v1", primary/fallback/nonce_storage според активната конфигурация. Кодът запазва историческия worker version 0.6.1; prompt_profile отличава новата версия на речника.
5. workers/wrangler.toml.example е примерен config, НЕ е готов за CLI deployment без реалния KV namespace ID и съответните account настройки. При съществуващ Worker най-простият подход е dashboard code replacement, който запазва настройките. Не замествай работещата конфигурация с примерния файл.

## 4. WordPress
1. Plugins > Add New > Upload Plugin.
2. Избери отделния bg-voice-logger-v0.8.0.zip и Install Now > Replace current with uploaded (обновяване, не изтриване).
3. Запази всички текущи WordPress настройки, включително Google OAuth, Apps Script URL, folder/template IDs, STT URL/secret, app URL и локалните wp-config.php constants.
4. Отвори https://spasitelenclub.com/dka/ и провери WP 0.8.0 / JS 0.8.0-5e642967a700 в приложението. Презареди само когато няма активен запис. Не чисти браузърната памет, IndexedDB или локалната опашка.

## 5. Приемане и rollback
Първо създай отделна тестова акция. Провери Google вход, създаване/избор, диктовка, LOG/INFO/TEAM/TECH, снимки, оригинално аудио (стрийминг + резервно цялостно изтегляне), offline/online и еднократна синхронизация без дубликати, Android Chrome и iPhone Safari/PWA. iOS не гарантира background upload при заключване.
При проблем върни стария WordPress ZIP, стария GAS revision в същия deployment и стария Cloudflare Worker version. Запази опашката и неизпратените файлове; провери op_id преди повторно изпращане.

Архивът не съдържа частни ключове, Google IDs, лични данни или експортирани production credentials. Използва наличната конфигурация на съществуващата инсталация.
